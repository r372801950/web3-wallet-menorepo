import InfoContract from '@abis/InfoContract.json';
export const CONTRACT_ADDRESS = '0x27Fd369084f74FBd55a5389a5AA5a9FF43FC0dD5';
export const CONTRACT_ABI = InfoContract.abi;
