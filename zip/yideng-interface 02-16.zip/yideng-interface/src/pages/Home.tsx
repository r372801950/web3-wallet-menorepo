const HomePage = () => {
  return (
    <>
      <h1>HomePage</h1>
    </>
  );
};
export default HomePage;
