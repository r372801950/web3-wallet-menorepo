module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
    // postcssPresetEnv({
    //     "browsers": [
    //         "> 0.2% and not dead"
    //     ]
    // })
  },
};
