describe('综合性的测试', () => {
  it('简单的测试', () => {
    expect(11).toBe(11);
  });
});
